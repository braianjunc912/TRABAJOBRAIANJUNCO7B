# Mockup

Se realizó un mockup del sistema de inventario tomando como referencia una interfaz moderna y profesional inspirada en (https://www.odoo.com/es)

El diseño fue utilizado como base para desarrollar las pantallas del sistema y el estilo CSS aplicado al proyecto.

## Elementos diseñados en el mockup

- Pantalla principal
- Formularios de carga
- Tabla de productos
- Botones de acciones
- Navegación del sistema
- Diseño responsive

## Herramientas posibles utilizadas

- Figma
- Canva
- Photoshop
- Herramientas de diseño digital

## Objetivo del mockup

El mockup permitió organizar visualmente la estructura del sistema antes de aplicar el diseño final en HTML y CSS, facilitando una interfaz más moderna, clara y cómoda para el usuario.

## Entrega

En el informe final se debe incluir:

- El mockup completo
- Capturas de pantalla
- O el enlace al archivo de diseño utilizado