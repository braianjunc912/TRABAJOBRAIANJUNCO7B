# Documentación

En esta carpeta se incluye toda la documentación relacionada al sistema de inventario desarrollado.

## Contenido

- Informe de la entrega (PDF o Word)
- Mockup del sistema
- Recursos de diseño utilizados
- Referencias visuales

---

## Referencia visual del estilo

El diseño visual del sistema fue inspirado en la interfaz de :contentReference[oaicite:0]{index=0}, utilizando una estética moderna, minimalista y profesional basada en:

- Colores suaves y limpios
- Bordes redondeados
- Formularios modernos
- Tablas estilizadas
- Botones con efecto hover
- Diseño responsive

---

## Breve documentación

El sistema fue modificado únicamente en el apartado visual (CSS), manteniendo intacta toda la funcionalidad original del inventario.

### Cambios realizados

- Nuevo estilo visual inspirado en Odoo
- Mejora en formularios y botones
- Tablas más modernas y legibles
- Mejor organización visual
- Compatibilidad responsive para celulares

### Tecnologías utilizadas

- HTML5
- CSS3
- Google Fonts
